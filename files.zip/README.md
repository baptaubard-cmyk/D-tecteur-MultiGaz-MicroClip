# Détecteur multigaz – simulateur pour exercices

Page web pour téléphone qui simule un détecteur multigaz (CO, H₂S, LEL, O₂) : alarmes A1 / A2 / OL, théorie, scénarios.

- `index.html` : version téléphone (portrait uniquement)
- `version-complete.html` : version non limitée au téléphone

Ouvrir sur iPhone : Partager → « Sur l'écran d'accueil ».
Hors Claude, le mode formateur/stagiaire en direct n'est pas disponible : la page fonctionne en mode seul.
